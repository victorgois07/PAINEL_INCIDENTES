create procedure number_id_jail(IN `_col` varchar(40), IN `_table` varchar(40))
  BEGIN

    SET @com = CONCAT('SELECT a.',_col,' - 1 AS livre FROM ',_table,' AS a LEFT JOIN ',_table,' AS b ON a.',_col,' - 1 = b.',_col,' WHERE b.',_col,' IS NULL AND a.',_col,' > 1');
    PREPARE stmt1 FROM @com;
    EXECUTE stmt1;
    DEALLOCATE PREPARE stmt1;

  END;

